import os
import re
import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
from tqdm import tqdm

#CONFIG
IMG_SIZE = (128, 128)
TRAIN_DIR = 'train'
TEST_DIR = 'test'
OUTPUT_DIR = 'output/predicted_masks'
os.makedirs(OUTPUT_DIR, exist_ok=True)

#Augmented dataset loader
def load_all_pairs_with_aug(train_dir, img_size=(128, 128)):
    image_files = sorted([f for f in os.listdir(train_dir) if f.startswith('input_') and f.endswith('.jpg')])
    images, masks = [], []

    for img_file in image_files:
        index = img_file.split('_')[1].split('.')[0]
        mask_file = f'mask_{index}.png'

        img_path = os.path.join(train_dir, img_file)
        mask_path = os.path.join(train_dir, mask_file)

        img = cv2.imread(img_path)
        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)

        if img is None or mask is None:
            print(f"Skipping {img_file} — could not read image or mask.")
            continue

        img = cv2.resize(img, img_size) / 255.0
        mask = cv2.resize(mask, img_size)
        mask = (mask > 127).astype(np.float32)
        mask = np.expand_dims(mask, axis=-1)

        #Original
        images.append(img)
        masks.append(mask)

        #Horizontal flip
        images.append(np.flip(img, axis=1))
        masks.append(np.flip(mask, axis=1))

        #Vertical flip
        images.append(np.flip(img, axis=0))
        masks.append(np.flip(mask, axis=0))

        #180 degree rotation
        images.append(np.rot90(img, k=2))
        masks.append(np.rot90(mask, k=2))

        #Horizontal flip + 180 rotation
        img_flip_h = np.flip(img, axis=1)
        mask_flip_h = np.flip(mask, axis=1)
        images.append(np.rot90(img_flip_h, k=2))
        masks.append(np.rot90(mask_flip_h, k=2))

        #Vertical flip + 180 rotation
        img_flip_v = np.flip(img, axis=0)
        mask_flip_v = np.flip(mask, axis=0)
        images.append(np.rot90(img_flip_v, k=2))
        masks.append(np.rot90(mask_flip_v, k=2))

    return np.array(images), np.array(masks)



# === U-Net model ===
def build_model(input_shape=(128, 128, 3)):
    inputs = layers.Input(input_shape)

    c1 = layers.Conv2D(16, 3, activation='relu', padding='same')(inputs)
    c1 = layers.Conv2D(16, 3, activation='relu', padding='same')(c1)
    p1 = layers.MaxPooling2D()(c1)

    c2 = layers.Conv2D(32, 3, activation='relu', padding='same')(p1)
    c2 = layers.Conv2D(32, 3, activation='relu', padding='same')(c2)
    p2 = layers.MaxPooling2D()(c2)

    c3 = layers.Conv2D(64, 3, activation='relu', padding='same')(p2)
    c3 = layers.Conv2D(64, 3, activation='relu', padding='same')(c3)

    u1 = layers.UpSampling2D()(c3)
    u1 = layers.Concatenate()([u1, c2])
    c4 = layers.Conv2D(32, 3, activation='relu', padding='same')(u1)
    c4 = layers.Conv2D(32, 3, activation='relu', padding='same')(c4)

    u2 = layers.UpSampling2D()(c4)
    u2 = layers.Concatenate()([u2, c1])
    c5 = layers.Conv2D(16, 3, activation='relu', padding='same')(u2)
    c5 = layers.Conv2D(16, 3, activation='relu', padding='same')(c5)

    outputs = layers.Conv2D(1, 1, activation='sigmoid')(c5)
    return models.Model(inputs, outputs)

#Load training data with augmentation
print("🔍 Loading training data with augmentation...")
X, Y = load_all_pairs_with_aug(TRAIN_DIR)
print(f"✔️ Loaded {len(X)} image-mask pairs.")

#Build and compile model 
model = build_model()
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

#Train model epoch-by-epoch with debug predictions
for epoch in range(1, 101):
    print(f"Epoch {epoch}")
    model.fit(X, Y, epochs=1, batch_size=2, verbose=1)

    # Debug prediction on first training sample
    pred = model.predict(np.expand_dims(X[0], axis=0))[0, :, :, 0]
    print(f" → Prediction stats: min={pred.min():.3f}, max={pred.max():.3f}, mean={pred.mean():.3f}")

#Predict on test images
print("Generating predictions on test images...")
for fname in tqdm(os.listdir(TEST_DIR)):
    if fname.startswith('input_new') and fname.endswith('.jpg'):
        path = os.path.join(TEST_DIR, fname)
        img = cv2.imread(path)
        if img is None:
            print(f"Skipping {fname} — could not read image.")
            continue

        original_shape = (img.shape[1], img.shape[0])
        img_resized = cv2.resize(img, IMG_SIZE) / 255.0
        pred = model.predict(np.expand_dims(img_resized, axis=0))[0, :, :, 0]
        pred = (pred > 0.25).astype(np.uint8) * 255
        pred_resized = cv2.resize(pred, original_shape)
        cv2.imwrite(os.path.join(OUTPUT_DIR, fname.replace('.jpg', '_mask.png')), pred_resized)

print("✅ Done. Masks saved in:", OUTPUT_DIR)